package com.example.productcatalogservice.service.impl;

import com.example.productcatalogservice.entity.CategoryEntity;
import com.example.productcatalogservice.repository.CategoryRepository;
import com.example.productcatalogservice.service.ICategoriaService;
import org.springframework.stereotype.Service;

@Service
public class CategoryServiceImpl implements ICategoriaService {

   private final CategoryRepository categoriaRepository;

    public CategoryServiceImpl(CategoryRepository categoriaRepository) {
        this.categoriaRepository = categoriaRepository;
    }



    @Override
    public CategoryEntity findById(Long id) {
        return null;
    }

    @Override
    public CategoryEntity createProduct(String name) {
        return null;
    }

    @Override
    public CategoryEntity FindByName(String name) {
        return null;
    }

    @Override
    public CategoryEntity createCategory(CategoryEntity category) {
        return null;
    }

    @Override
    public CategoryEntity updateCategory(CategoryEntity category) {
        return null;
    }

    @Override
    public void deleteCategory(Long id) {

    }

}
