package com.example.productcatalogservice.service.impl;

import com.example.productcatalogservice.entity.ProductEntity;
import com.example.productcatalogservice.service.IProductService;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl  implements IProductService {
    @Override
    public ProductEntity finByID(Long id) {
        return null;
    }

    @Override
    public ProductEntity findByName(String name) {
        return null;
    }

    @Override
    public ProductEntity finByDescription(String descripcion) {
        return null;
    }

    @Override
    public ProductEntity createProduct(String Product) {
        return null;
    }

    @Override
    public ProductEntity updateProduct(String Product) {
        return null;
    }

    @Override
    public void deleteProduct(Long id) {

    }


}
