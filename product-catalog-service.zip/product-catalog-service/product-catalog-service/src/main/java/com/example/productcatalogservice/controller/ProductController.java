package com.example.productcatalogservice.controller;

import com.example.productcatalogservice.entity.ProductEntity;
import com.example.productcatalogservice.service.ICategoriaService;
import com.example.productcatalogservice.service.IProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


import java.util.List;

    @RestController
    @RequestMapping("/products")
    @RequiredArgsConstructor
    public class ProductController {


        private final IProductService iProductService;




        @GetMapping("/{id}")
        public ResponseEntity<ProductEntity> getProductById(@PathVariable Long id) {
            ProductEntity product = iProductService.finByID(id);
            return ResponseEntity.ok(product);
        }

        @GetMapping ("/name")
        public ResponseEntity<ProductEntity> geyByName(@RequestBody ProductEntity product) {
            ProductEntity createdProduct = iProductService.findByName("");
            return new ResponseEntity<>(createdProduct, HttpStatus.CREATED);
        }
        @GetMapping ("/description")
        public ResponseEntity<ProductEntity> getByDescription(@RequestBody ProductEntity product) {
            ProductEntity createdProduct = iProductService.finByDescription("");
            return new ResponseEntity<>(createdProduct, HttpStatus.CREATED);
        }
        @PostMapping
        public  ResponseEntity<ProductEntity>createProduct(@RequestBody ProductEntity product){
            ProductEntity createProduct = iProductService.createProduct(String.valueOf(product));
            return new ResponseEntity<>(createProduct, HttpStatus.CREATED);
        }
        @PutMapping
        public ResponseEntity<ProductEntity> updateProduct(@RequestBody ProductEntity product) {
            ProductEntity updatedProduct = iProductService.updateProduct(String.valueOf(product));
            return ResponseEntity.ok(updatedProduct);
        }

        @DeleteMapping("/{id}")
        public ResponseEntity<Void> deleteProduct(@PathVariable Long id) {
            iProductService.deleteProduct(id);
            return ResponseEntity.noContent().build();
        }

    }



