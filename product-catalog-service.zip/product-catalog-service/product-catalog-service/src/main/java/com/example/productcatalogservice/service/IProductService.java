package com.example.productcatalogservice.service;

import com.example.productcatalogservice.entity.ProductEntity;

public interface IProductService {
    ProductEntity finByID(Long id);
    ProductEntity findByName(String name );
    ProductEntity finByDescription(String descripcion);
    ProductEntity createProduct(String Product);
    ProductEntity updateProduct(String Product);
   void deleteProduct(Long id);

}
