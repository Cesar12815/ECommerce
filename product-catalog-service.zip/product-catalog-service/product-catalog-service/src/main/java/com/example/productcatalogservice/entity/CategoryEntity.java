package com.example.productcatalogservice.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Set;

@Entity
public class CategoryEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(mappedBy = "categoryEntity")  // Asegúrate de que este nombre coincida con el nombre del atributo en ProductEntity
    private Set<ProductEntity> productEntities;

    @Column(name = "name")
    private String name;
}
