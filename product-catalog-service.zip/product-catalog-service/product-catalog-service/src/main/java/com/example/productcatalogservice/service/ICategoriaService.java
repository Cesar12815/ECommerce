package com.example.productcatalogservice.service;

import com.example.productcatalogservice.entity.CategoryEntity;

public interface ICategoriaService {

    CategoryEntity findById(Long id);
    CategoryEntity createProduct(String name);
    CategoryEntity FindByName(String name);
    CategoryEntity createCategory(CategoryEntity category);
    CategoryEntity updateCategory(CategoryEntity category);
    void deleteCategory(Long id);
}
