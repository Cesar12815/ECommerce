package com.example.productcatalogservice.controller;

import com.example.productcatalogservice.entity.CategoryEntity;
import com.example.productcatalogservice.entity.ProductEntity;
import com.example.productcatalogservice.service.ICategoriaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/categor")
@RequiredArgsConstructor
public class CategorController {

private final ICategoriaService iCategoriaService ;

    @GetMapping("/{id}")
    public ResponseEntity<CategoryEntity> getCategoryById(@PathVariable Long id) {
        CategoryEntity categoria = iCategoriaService.findById(id);
        return ResponseEntity.ok(categoria);
    }
    @GetMapping("/name")
    public ResponseEntity<CategoryEntity> getByName(@RequestParam String name) {
        CategoryEntity category = iCategoriaService.FindByName(name);
        return ResponseEntity.ok(category);
    }

    @PostMapping
    public ResponseEntity<CategoryEntity> getByName(@RequestBody ProductEntity product) {
        CategoryEntity categoryEntity = iCategoriaService.createProduct("");
        return new ResponseEntity<>(categoryEntity, HttpStatus.CREATED);
    }
    @PutMapping
    public ResponseEntity<CategoryEntity>updateCategory(@RequestBody CategoryEntity category){
        CategoryEntity updateCategory = iCategoriaService.updateCategory(category);
        return ResponseEntity.ok(updateCategory);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void>deleteCategory(@PathVariable Long id){
        iCategoriaService.deleteCategory(id);
        return ResponseEntity.noContent().build();
    }


}
